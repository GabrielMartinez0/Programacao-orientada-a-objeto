package Exercicios1.ex1;

public class Main {
    public static void main(String[] args) {
        TestaAluno.main(args);
    }
}
